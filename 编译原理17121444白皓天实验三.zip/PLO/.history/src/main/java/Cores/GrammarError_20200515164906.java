/*
 * @Author: your name
 * @Date: 2020-05-15 16:49:04
 * @LastEditTime: 2020-05-15 16:49:06
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \PLO\src\main\java\Cores\GrammarError.java
 */ 
package Cores;

public class GrammarError {

}

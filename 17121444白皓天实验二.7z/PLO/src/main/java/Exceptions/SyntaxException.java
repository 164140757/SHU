package Exceptions;

public class SyntaxException extends Throwable {
    public SyntaxException(){

    }
}

package Cores.Lexer.Token;

public class Token {
    public final String type;
    public Token(String type) {
        this.type = type;
    }
}

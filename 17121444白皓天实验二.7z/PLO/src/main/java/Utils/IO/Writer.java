package Utils.IO;

import IO.AbstractFileWriter;

import java.io.IOException;
import java.util.Vector;

public class Writer extends AbstractFileWriter {
    public Writer(String outputPath) throws IOException {
        super(outputPath);
    }

}

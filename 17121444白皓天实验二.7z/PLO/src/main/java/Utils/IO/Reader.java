package Utils.IO;

import IO.AbstractFileReader;

import java.io.IOException;

public class Reader extends AbstractFileReader {
    public Reader(String inputPath) throws IOException {
        super(inputPath);
    }
}
